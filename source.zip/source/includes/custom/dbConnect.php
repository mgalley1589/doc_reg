<?php

 $connection = mysql_connect('localhost', 'root', '') 
                or die(mysql_error()); 

            $db = mysql_select_db('gha', $connection) 
                or die(mysql_error()); 
                

?>