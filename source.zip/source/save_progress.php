<?php

// We're saving the progress

// Connect to the database.

include('includes/custom/dbConnect.php');

// Get the data out
echo "<pre>";
print_r($_POST);
echo "</pre>";
exit();
