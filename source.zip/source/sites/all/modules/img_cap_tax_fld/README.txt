This is a Drupal Module - Image Caption Taxonomy Field
It implements the Image Caption Taxonomy field for CCK

There is a companion article explaining this module's development
at http://poplarware.com/articles/cck_field_module

Copyright 2009-10 Jennifer Hodgdon, Poplar ProductivityWare LLC

Licensed under the GNU Public License (see LICENSE.txt)

